import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Train Seat Reservation';
  maxSeatsPerRow = 7;
  totalSeats = 80;
  seats = [];
  seatsToBook: number = 0;
  bookedSeats: number[] = [];
  errorMessage: string = '';

  constructor() {
    this.initializeSeats();
  }

  // Initialize the seating arrangement for the train coach
  initializeSeats() {
    let seatId = 1;
    // Create 11 rows of 7 seats each
    for (let i = 1; i <= 11; i++) {
      this.seats.push(
        Array(this.maxSeatsPerRow)
          .fill(null)
          .map(() => ({ seatId: seatId++, isBooked: false }))
      );
    }
    // Create the last row of 3 seats
    this.seats.push(
      Array(3)
        .fill(null)
        .map(() => ({ seatId: seatId++, isBooked: false }))
    );
  }

  // Function to handle seat booking based on availability
  bookSeats() {
    this.bookedSeats = [];
    this.errorMessage = '';

    // Check if the input is valid
    if (this.seatsToBook < 1 || this.seatsToBook > 7) {
      this.errorMessage = 'You can only book between 1 and 7 seats at a time.';
      return;
    }

    // Try booking seats in a single row
    for (let row of this.seats) {
      let availableSeats = row.filter(seat => !seat.isBooked);
      if (availableSeats.length >= this.seatsToBook) {
        let booked = availableSeats.slice(0, this.seatsToBook);
        booked.forEach(seat => (seat.isBooked = true));
        this.bookedSeats = booked.map(seat => seat.seatId);
        return;
      }
    }

    // Fallback: book nearby seats across rows
    let nearbySeats = [];
    for (let row of this.seats) {
      let availableSeats = row.filter(seat => !seat.isBooked);
      nearbySeats.push(...availableSeats);
      if (nearbySeats.length >= this.seatsToBook) {
        nearbySeats.slice(0, this.seatsToBook).forEach(seat => (seat.isBooked = true));
        this.bookedSeats = nearbySeats.map(seat => seat.seatId).slice(0, this.seatsToBook);
        return;
      }
    }

    // If not enough seats are available
    this.errorMessage = 'Not enough seats are available for booking.';
  }
}
